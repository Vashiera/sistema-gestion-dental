from flask import render_template

def registrar_administracion(app):

    @app.route("/administracion")
    def administracion():
        return render_template("administracion/administracion.html")