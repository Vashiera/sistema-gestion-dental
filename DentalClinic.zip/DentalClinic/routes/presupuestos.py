import json

from flask import render_template, request, redirect, url_for

from models.presupuesto import (
    obtener_presupuestos,
    crear_presupuesto,
    obtener_presupuesto_por_id
)

from models.paciente import obtener_lista_pacientes
from models.catalogo_tratamiento import obtener_catalogo_tratamientos


def registrar_presupuestos(app):

    @app.route("/presupuestos")
    def presupuestos():
        lista_presupuestos = obtener_presupuestos()
        lista_pacientes = obtener_lista_pacientes()
        catalogo = obtener_catalogo_tratamientos()

        return render_template(
            "presupuestos/presupuestos.html",
            presupuestos=lista_presupuestos,
            pacientes=lista_pacientes,
            catalogo=catalogo
        )

    @app.route("/presupuestos/crear", methods=["POST"])
    def crear_presupuesto_route():
        detalles = json.loads(request.form["detalles_json"])

        crear_presupuesto(
            request.form["id_paciente"],
            1,
            request.form["fecha"],
            request.form["fecha_vencimiento"],
            request.form["estado"],
            request.form["observaciones"],
            detalles
        )

        return redirect(url_for("presupuestos"))

    @app.route("/presupuesto/<int:id>")
    def presupuesto_detalle(id):
        presupuesto, detalle = obtener_presupuesto_por_id(id)

        return render_template(
            "presupuestos/presupuesto-detalle.html",
            presupuesto=presupuesto,
            detalle=detalle
        )