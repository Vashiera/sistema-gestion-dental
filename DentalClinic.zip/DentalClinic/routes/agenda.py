from flask import render_template

def registrar_agenda(app):

    @app.route("/agenda")
    def agenda():
        return render_template("agenda/agenda.html")