from flask import render_template

def registrar_dashboard(app):

    @app.route("/dashboard")
    def dashboard():
        return render_template("dashboard/dashboard.html")