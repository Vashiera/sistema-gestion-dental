from flask import render_template

def registrar_documentos(app):

    @app.route("/documentos")
    def documentos():
        return render_template("documentos/documentos.html")