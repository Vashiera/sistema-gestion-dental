from flask import render_template, request, redirect, url_for

from models.paciente import (
    obtener_pacientes,
    crear_paciente,
    obtener_paciente_por_id
)


def registrar_pacientes(app):

    @app.route("/pacientes")
    def pacientes():

        lista_pacientes = obtener_pacientes()

        return render_template(
            "pacientes/pacientes.html",
            pacientes=lista_pacientes
        )


    @app.route("/pacientes/crear", methods=["POST"])
    def crear_paciente_route():

        crear_paciente(
            request.form["rut"],
            request.form["nombre"],
            request.form["apellido"],
            request.form["telefono"],
            request.form["correo"],
            request.form["direccion"],
            request.form["fecha_nacimiento"]
        )

        return redirect(url_for("pacientes"))


    @app.route("/ficha-paciente/<int:id>")
    def ficha_paciente(id):

        paciente = obtener_paciente_por_id(id)

        if paciente is None:
            return redirect(url_for("pacientes"))

        return render_template(
            "pacientes/ficha-paciente.html",
            paciente=paciente
        )