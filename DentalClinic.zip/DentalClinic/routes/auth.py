from flask import render_template, request, redirect, url_for, session

def registrar_auth(app):

    @app.route("/")
    def login():
        return render_template("index.html")

    @app.route("/iniciar-sesion", methods=["POST"])
    def iniciar_sesion():
        usuario = request.form["usuario"]
        rol = request.form["rol"]

        session["usuario"] = usuario
        session["rol"] = rol

        return redirect(url_for("dashboard"))

    @app.route("/cerrar-sesion")
    def cerrar_sesion():
        session.clear()
        return redirect(url_for("login"))