from flask import render_template, request, redirect, url_for

from models.tratamiento import (
    obtener_tratamientos,
    crear_tratamiento,
    obtener_tratamiento_por_id
)

from models.paciente import obtener_lista_pacientes
from models.catalogo_tratamiento import obtener_catalogo_tratamientos


def registrar_tratamientos(app):

    @app.route("/tratamientos")
    def tratamientos():

        lista_tratamientos = obtener_tratamientos()
        lista_pacientes = obtener_lista_pacientes()
        catalogo = obtener_catalogo_tratamientos()

        return render_template(
            "tratamientos/tratamientos.html",
            tratamientos=lista_tratamientos,
            pacientes=lista_pacientes,
            catalogo=catalogo
        )


    @app.route("/tratamientos/crear", methods=["POST"])
    def crear_tratamiento_route():

        crear_tratamiento(
            request.form["id_paciente"],
            1,  # Temporal: usuario logueado
            request.form["id_catalogo"],
            request.form["descripcion"],
            request.form["valor_presupuestado"],
            request.form["estado"],
            request.form["fecha_inicio"]
        )

        return redirect(url_for("tratamientos"))


    @app.route("/tratamiento/<int:id>")
    def tratamiento(id):

        tratamiento = obtener_tratamiento_por_id(id)

        return render_template(
            "tratamientos/tratamiento.html",
            tratamiento=tratamiento
        )