import os

class Config:
    SECRET_KEY = "dentalclinic_secret_key"

    MYSQL_HOST = "localhost"
    MYSQL_PORT = 3306
    MYSQL_USER = "root"
    MYSQL_PASSWORD = "DentalClinic2026!"
    MYSQL_DB = "dentalclinic"