from database.conexion import obtener_conexion


def formatear_rut(rut):
    rut = rut.replace(".", "").replace("-", "").upper().strip()

    cuerpo = rut[:-1]
    dv = rut[-1]

    cuerpo_formateado = ""
    contador = 0

    for numero in reversed(cuerpo):
        if contador == 3:
            cuerpo_formateado = "." + cuerpo_formateado
            contador = 0

        cuerpo_formateado = numero + cuerpo_formateado
        contador += 1

    return f"{cuerpo_formateado}-{dv}"


def formatear_telefono(telefono):
    telefono = telefono.replace("+", "").replace(" ", "").strip()

    if telefono.startswith("56"):
        telefono = telefono[2:]

    if telefono.startswith("9") and len(telefono) == 9:
        return f"+56 9 {telefono[1:5]} {telefono[5:]}"

    return telefono


def formatear_texto(texto):
    return texto.strip().title()


def obtener_pacientes():
    conexion = obtener_conexion()
    cursor = conexion.cursor(dictionary=True)

    cursor.execute("""
        SELECT id_paciente, rut, nombre, apellido, telefono, correo
        FROM pacientes
        ORDER BY id_paciente DESC
    """)

    pacientes = cursor.fetchall()

    cursor.close()
    conexion.close()

    return pacientes


def crear_paciente(rut, nombre, apellido, telefono, correo, direccion, fecha_nacimiento):
    rut = formatear_rut(rut)
    nombre = formatear_texto(nombre)
    apellido = formatear_texto(apellido)
    telefono = formatear_telefono(telefono)
    correo = correo.strip().lower()
    direccion = direccion.strip()

    if fecha_nacimiento == "":
        fecha_nacimiento = None

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        INSERT INTO pacientes (
            rut, nombre, apellido, telefono, correo, direccion, fecha_nacimiento
        ) VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, (
        rut,
        nombre,
        apellido,
        telefono,
        correo,
        direccion,
        fecha_nacimiento
    ))

    conexion.commit()

    cursor.close()
    conexion.close()

def obtener_paciente_por_id(id_paciente):
    conexion = obtener_conexion()
    cursor = conexion.cursor(dictionary=True)

    cursor.execute("""
        SELECT id_paciente, rut, nombre, apellido, telefono, correo, direccion, fecha_nacimiento
        FROM pacientes
        WHERE id_paciente = %s
    """, (id_paciente,))

    paciente = cursor.fetchone()

    cursor.close()
    conexion.close()

    return paciente

def obtener_lista_pacientes():

    conexion = obtener_conexion()
    cursor = conexion.cursor(dictionary=True)

    cursor.execute("""
        SELECT
            id_paciente,
            nombre,
            apellido
        FROM pacientes
        ORDER BY nombre
    """)

    pacientes = cursor.fetchall()

    cursor.close()
    conexion.close()

    return pacientes