from database.conexion import obtener_conexion


def obtener_tratamientos():

    conexion = obtener_conexion()
    cursor = conexion.cursor(dictionary=True)

    cursor.execute("""
        SELECT
            t.id_tratamiento,
            t.id_paciente,
            t.id_catalogo,
            c.nombre_tratamiento,
            c.precio_base,
            t.descripcion,
            t.valor_presupuestado,
            t.estado,
            t.fecha_inicio,
            p.nombre,
            p.apellido
        FROM tratamientos t
        INNER JOIN pacientes p
            ON t.id_paciente = p.id_paciente
        INNER JOIN catalogo_tratamientos c
            ON t.id_catalogo = c.id_catalogo
        ORDER BY t.id_tratamiento DESC
    """)

    tratamientos = cursor.fetchall()

    cursor.close()
    conexion.close()

    return tratamientos


def crear_tratamiento(
    id_paciente,
    id_usuario,
    id_catalogo,
    descripcion,
    valor_presupuestado,
    estado,
    fecha_inicio
):

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        INSERT INTO tratamientos (
            id_paciente,
            id_usuario,
            id_catalogo,
            descripcion,
            valor_presupuestado,
            estado,
            fecha_inicio
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """, (
        id_paciente,
        id_usuario,
        id_catalogo,
        descripcion,
        valor_presupuestado,
        estado,
        fecha_inicio
    ))

    conexion.commit()

    cursor.close()
    conexion.close()


def obtener_tratamiento_por_id(id_tratamiento):

    conexion = obtener_conexion()
    cursor = conexion.cursor(dictionary=True)

    cursor.execute("""
        SELECT
            t.id_tratamiento,
            t.id_paciente,
            t.id_usuario,
            t.id_catalogo,
            t.descripcion,
            t.valor_presupuestado,
            t.estado,
            t.fecha_inicio,
            p.nombre,
            p.apellido,
            c.nombre_tratamiento,
            c.precio_base
        FROM tratamientos t

        INNER JOIN pacientes p
            ON t.id_paciente = p.id_paciente

        INNER JOIN catalogo_tratamientos c
            ON t.id_catalogo = c.id_catalogo

        WHERE t.id_tratamiento = %s
    """, (id_tratamiento,))

    tratamiento = cursor.fetchone()

    cursor.close()
    conexion.close()

    return tratamiento